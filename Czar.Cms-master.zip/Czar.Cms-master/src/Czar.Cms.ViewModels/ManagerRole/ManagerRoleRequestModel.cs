﻿/**
*┌──────────────────────────────────────────────────────────────┐
*│　描    述：ManagerRole查询实体                                                    
*│　作    者：yilezhu                                             
*│　版    本：1.0                                                 
*│　创建时间：2018/12/30 16:07:13                             
*└──────────────────────────────────────────────────────────────┘
*┌──────────────────────────────────────────────────────────────┐
*│　命名空间： Czar.Cms.ViewModels                                   
*│　类    名： ManagerRoleRequestModel                                      
*└──────────────────────────────────────────────────────────────┘
*/
using System;
using System.Collections.Generic;
using System.Text;

namespace Czar.Cms.ViewModels
{
    public class ManagerRoleRequestModel:PageModel
    {
    }
}
