﻿/**
*┌──────────────────────────────────────────────────────────────┐
*│　描    述：任务调度结果                                                    
*│　作    者：yilezhu                                             
*│　版    本：1.0                                                 
*│　创建时间：2019/3/13 10:22:01                             
*└──────────────────────────────────────────────────────────────┘
*┌──────────────────────────────────────────────────────────────┐
*│　命名空间： Czar.Cms.ViewModels.ResultModel                                   
*│　类    名： ScheduleResult                                      
*└──────────────────────────────────────────────────────────────┘
*/
using System;
using System.Collections.Generic;
using System.Text;

namespace Czar.Cms.ViewModels
{
    public class ScheduleResult:BaseResult
    {
    }
}
