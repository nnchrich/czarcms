﻿/**
*┌──────────────────────────────────────────────────────────────┐
*│　描    述：Menu查询实体                                                    
*│　作    者：yilezhu                                             
*│　版    本：1.0                                                 
*│　创建时间：2019/1/5 17:08:10                             
*└──────────────────────────────────────────────────────────────┘
*┌──────────────────────────────────────────────────────────────┐
*│　命名空间： Czar.Cms.ViewModels.Menu                                   
*│　类    名： MenuRequestModel                                      
*└──────────────────────────────────────────────────────────────┘
*/
using System;
using System.Collections.Generic;
using System.Text;

namespace Czar.Cms.ViewModels
{
    public class MenuRequestModel : PageModel
    {
    }
}
