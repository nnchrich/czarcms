﻿/**
*┌──────────────────────────────────────────────────────────────┐
*│　描    述：TaskInfo查询实体                                                    
*│　作    者：yilezhu                                             
*│　版    本：1.0                                                 
*│　创建时间：2019/3/13 11:29:47                             
*└──────────────────────────────────────────────────────────────┘
*┌──────────────────────────────────────────────────────────────┐
*│　命名空间： Czar.Cms.ViewModels.TaskInfo                                   
*│　类    名： TaskInfoRequestModel                                      
*└──────────────────────────────────────────────────────────────┘
*/
using System;
using System.Collections.Generic;
using System.Text;

namespace Czar.Cms.ViewModels
{
    public class TaskInfoRequestModel:PageModel
    {
    }
}
