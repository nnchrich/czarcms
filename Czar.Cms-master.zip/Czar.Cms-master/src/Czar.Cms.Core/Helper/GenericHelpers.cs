﻿/**
*┌──────────────────────────────────────────────────────────────┐
*│　描    述：List转成Tree                                                    
*│　作    者：yilezhu                                             
*│　版    本：1.0                                                 
*│　创建时间：2019/1/5 12:14:39                             
*└──────────────────────────────────────────────────────────────┘
*┌──────────────────────────────────────────────────────────────┐
*│　命名空间： Czar.Cms.Core.Helper                                   
*│　类    名： GenericHelpers                                      
*└──────────────────────────────────────────────────────────────┘
*/
using Czar.Cms.Core.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Czar.Cms.Core.Helper
{
    public static class GenericHelpers
    {
    
        
    }
}
